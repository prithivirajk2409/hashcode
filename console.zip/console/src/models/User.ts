export type UserProfile = {
    userId : number,
    userName: string,
    emailId : string

}